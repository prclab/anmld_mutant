function [m,o,deg_col,slow_vec_anm,file1,file2,file3,rest_mode]=anm_gnm_target_overlap(cycle,slow_vectors_anm_initial,fname1,fname2,fname3)

[d1, d2, d3, d4, d5, x_1, y_1, z_1, d6]=textread(fname1,'%s%f%s%s%f%f%f%f%s','headerlines',7);


x=[x_1'];
y=[y_1'];
z=[z_1'];

% to erase the last line ('END') of the pdb file
x=[x(1:size(x,2)-1)];
y=[y(1:size(y,2)-1)];
z=[z(1:size(z,2)-1)];


resnum=size(x,2);
frame=size(x,1);

rcut_gnm=10.0;

rcut_anm= 13.0;

resnum3=resnum*3;

% gamma constant
ga=1;

% This is to define the range of ANM modes [mode_beg,mode_max] to be used
mode_beg=1;
mode_max=100;

restricted_modes=[];

new_restricted_modes=restricted_modes; % will be updated with matching modes after cycle 1

%% preallocate arrays
r2=zeros(resnum,resnum);
cont=zeros(resnum,resnum);
invcont=zeros(resnum,resnum);
invcont_av10=zeros(resnum,resnum);
hessian=zeros(resnum3,resnum3);
invhess=zeros(resnum3,resnum3);
invhess_av10=zeros(resnum3,resnum3);
invhess1=zeros(resnum3,resnum3);
invhess2=zeros(resnum3,resnum3);
invhess3=zeros(resnum3,resnum3);

U=zeros(resnum,resnum);
S=zeros(resnum,resnum);
V=zeros(resnum,resnum);
w_snsh=zeros(resnum,frame);
w1_snsh=zeros(resnum,frame);
w2_snsh=zeros(resnum,frame);
w3_snsh=zeros(resnum,frame);
Ua=zeros(resnum3,resnum3);
Sa=zeros(resnum3,resnum3);
Va=zeros(resnum3,resnum3);
fluc_x2=zeros(resnum);
fluc_y2=zeros(resnum);
fluc_z2=zeros(resnum);
fluc_x2_2=zeros(resnum);
fluc_y2_2=zeros(resnum);
fluc_z2_2=zeros(resnum);
fluc_x2_3=zeros(resnum);
fluc_y2_3=zeros(resnum);
fluc_z2_3=zeros(resnum);

w_snsh_a=zeros(resnum3,frame);

%%
for snsh_anm=1:frame
    
    for j=1:resnum
        for k=1:resnum
            distx = x(snsh_anm,j)-x(snsh_anm,k);
            disty = y(snsh_anm,j)-y(snsh_anm,k);
            distz = z(snsh_anm,j)-z(snsh_anm,k);
            
            r2(j,k)=distx^2+disty^2+distz^2;
            
            r=sqrt(distx^2+disty^2+distz^2);
            
            % Kirchhoff
            if (r <= rcut_gnm && j~=k && r > 0.0001)
                cont(j,k)=-1;
            else
                cont(j,k)=0;
            end
            
            % Hessian
            if (r <= rcut_anm && k~=j)
                % Creation of Hii
                % diagonals
                hessian(3*j-2,3*j-2)=hessian(3*j-2,3*j-2)+ga*distx*distx/r2(j,k); % x, 3j-2
                hessian(3*j-1,3*j-1)=hessian(3*j-1,3*j-1)+ga*disty*disty/r2(j,k); % y, 3j-1
                hessian(3*j,3*j)=hessian(3*j,3*j)+ga*distz*distz/r2(j,k);         % z, 3j
                
                % off-diagonals
                hessian(3*j-2,3*j-1)=hessian(3*j-2,3*j-1)+ga*distx*disty/r2(j,k); % xy
                hessian(3*j-2,3*j)=hessian(3*j-2,3*j)+ga*distx*distz/r2(j,k);     % xz
                
                hessian(3*j-1,3*j-2)=hessian(3*j-1,3*j-2)+ga*disty*distx/r2(j,k); % yx
                hessian(3*j-1,3*j)=hessian(3*j-1,3*j)+ga*disty*distz/r2(j,k);     % yz
                
                hessian(3*j,3*j-2)=hessian(3*j,3*j-2)+ga*distz*distx/r2(j,k); % zx
                hessian(3*j,3*j-1)=hessian(3*j,3*j-1)+ga*distz*disty/r2(j,k); % zy
                
                % Creation of Hij
                % diagonals
                hessian(3*j-2,3*k-2)=-1*ga*distx*distx/r2(j,k); % x, 3j-2
                hessian(3*j-1,3*k-1)=-1*ga*disty*disty/r2(j,k); % y, 3j-1
                hessian(3*j,3*k)=    -1*ga*distz*distz/r2(j,k); % z, 3j
                
                % off-diagonals
                hessian(3*j-2,3*k-1)=-1*ga*distx*disty/r2(j,k); % xy
                hessian(3*j-2,3*k)=  -1*ga*distx*distz/r2(j,k); % xz
                
                hessian(3*j-1,3*k-2)=-1*ga*disty*distx/r2(j,k); % yx
                hessian(3*j-1,3*k)=  -1*ga*disty*distz/r2(j,k); % yz
                
                hessian(3*j,3*k-2)=  -1*ga*distz*distx/r2(j,k); % zx
                hessian(3*j,3*k-1)=  -1*ga*distz*disty/r2(j,k); % zy
                
            end
        end
    end
    
    % detailed balance for connectivity matrix
    diagonal=sum(cont(:,:));
    
    for j=1:resnum
        for i=1:resnum
            if i == j
                cont(i,j)=-1*diagonal(i); % Kirchhoff
            end
        end
    end
    
    [U(:,:),S(:,:),V(:,:)]=svd(cont(:,:));
    w=diag(S(:,:));
    % to export as output
    w_snsh(:,snsh_anm)=diag(S(:,:));
    
    w1_snsh(snsh_anm)=w_snsh(resnum-1,snsh_anm);
    w2_snsh(snsh_anm)=w_snsh(resnum-2,snsh_anm);
    w3_snsh(snsh_anm)=w_snsh(resnum-3,snsh_anm);
    
    
    [Ua(:,:),Sa(:,:),Va(:,:)]=svd(hessian(:,:));
    wa=diag(Sa(:,:));
    % to export as output
    w_snsh_a(:,snsh_anm)=diag(Sa(:,:));
    
    
    % GNM 10 slow eigenvectors and slow modes
    for j=resnum-1:-1:resnum-10
        for i=1:resnum
            slow_vectors_gnm(i,j)=V(i,j);
            slow_modes_gnm(i,j)=V(i,j)*V(i,j);
        end
    end
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % ANM 20 slow eigenvectors and slow modes, last column corresponds to first mode
    for j=resnum3-6:-1:1
        for i=1:resnum3
            slow_vectors_anm(i,j)=Va(i,j);
            %  slow_modes(i,j)=V(i,j)*V(i,j); % GNM
        end
    end
    
    
    % ANM
    for m=1:mode_max%20
        for n=1:resnum
            Vx(n,m)=slow_vectors_anm(3*n-2,resnum3-5-m);
            Vy(n,m)=slow_vectors_anm(3*n-1,resnum3-5-m);
            Vz(n,m)=slow_vectors_anm(3*n  ,resnum3-5-m);
        end
    end
    
    % ANM first column corresponds to first mode
    for m=1:mode_max
        for j=1:resnum
            slow_modes_anm(j,m)=(Vx(j,m)*Vx(j,m)+Vy(j,m)*Vy(j,m)+Vz(j,m)*Vz(j,m))/wa(resnum3-5-m);
            slow_modes_not_weighted_anm(j,m)=sqrt((Vx(j,m)*Vx(j,m)+Vy(j,m)*Vy(j,m)+Vz(j,m)*Vz(j,m)));
        end
    end
    
end


%%
eig_mag=0;
eig_mag_sum(resnum3)=0;

% Deformation factor
DF=0.2;

for i=1:mode_max;
    
    for j=1:resnum;
        
        eig_mag(j,i) = (Vx(j,i)^2+Vy(j,i)^2+Vz(j,i)^2);
        
        eig_mag_sum (i)= eig_mag_sum(i)+ eig_mag(j,i);
        
    end
    
    rescale(i) = DF/sqrt(eig_mag_sum(i)/resnum);
end

for i=1:mode_max;
    for j=1:resnum;
        
        x_a(j,i)=x(j)+Vx(j,i)*rescale(i);
        x_b(j,i)=x(j)-Vx(j,i)*rescale(i);
        
        y_a(j,i)=y(j)+Vy(j,i)*rescale(i);
        y_b(j,i)=y(j)-Vy(j,i)*rescale(i);
        
        z_a(j,i)=z(j)+Vz(j,i)*rescale(i);
        z_b(j,i)=z(j)-Vz(j,i)*rescale(i);
    end
end



%%
PDBdata = pdb2mat(fname2);

PDBdata_ab = pdb2mat(fname2);

PDBdata_initial = pdb2mat(fname1);

PDBdata_target = pdb2mat(fname3);


diff_vector=[PDBdata_target.X-PDBdata_initial.X; PDBdata_target.Y-PDBdata_initial.Y; PDBdata_target.Z-PDBdata_initial.Z];


slow_vec_anm=slow_vectors_anm;


count=0;
count3=0;


rest_mode=new_restricted_modes

countx=0;

for mode=mode_beg:mode_max
    mode_vectors=[Vx(:,mode) Vy(:,mode) Vz(:,mode)];
    if ismember(mode,new_restricted_modes)==0
        overlap_diff_mode_reshape(mode,:)=dot(reshape(diff_vector,resnum3,1),reshape(mode_vectors',resnum3,1))/(norm(reshape(diff_vector,resnum3,1))*norm(reshape(mode_vectors',resnum3,1)));
        
        overlap_sum=sum(overlap_diff_mode_reshape.^2);
    end
    if ismember(mode,new_restricted_modes)==1
        countx=countx+1;
        overlap_diff_mode_reshape_restricted(countx,:)=dot(reshape(diff_vector,resnum3,1),reshape(mode_vectors',resnum3,1))/(norm(reshape(diff_vector,resnum3,1))*norm(reshape(mode_vectors',resnum3,1)));
    end
end

[overlap_desc,index_overlap_desc]=(sort(abs(overlap_diff_mode_reshape),'descend'))


ov = 0;

tfile = fopen(sprintf('tleap_anm_pdbs_cycle%d.in',cycle),'w');
fprintf(tfile,'source leaprc.ff03.r1 \n');




anmVfile = fopen(sprintf('ANMmodeshapes_SEL'),'a');

fprintf(anmVfile,'Cycle %d Ov1_Mode %d %7.4f\n\n', cycle, index_overlap_desc(1), w_snsh_a(resnum3-5-index_overlap_desc(1),snsh_anm));
fprintf(anmVfile,'\nCycle %d Selected ANM Slow Mode Vector x component Vx\n', cycle);
fprintf(anmVfile,[repmat('%7.4f\t', 1, size(Vx(:,index_overlap_desc(1)), 2)) '\n'],Vx(:,index_overlap_desc(1))');
fprintf(anmVfile,'\nCycle %d Selected ANM Slow Mode Vector y component Vy\n', cycle);
fprintf(anmVfile,[repmat('%7.4f\t', 1, size(Vy(:,index_overlap_desc(1)), 2)) '\n'],Vy(:,index_overlap_desc(1))');
fprintf(anmVfile,'\nCycle %d Selected ANM Slow Mode Vector z component Vz\n', cycle);
fprintf(anmVfile,[repmat('%7.4f\t', 1, size(Vz(:,index_overlap_desc(1)), 2)) '\n'],Vz(:,index_overlap_desc(1))');
fprintf(anmVfile,'\nCycle %d Selected ANM Slow Mode Shape\n',cycle);
fprintf(anmVfile,[repmat('%7.4f\t', 1, size(slow_modes_anm(:,index_overlap_desc(1)), 2)) '\n'],slow_modes_anm(:,index_overlap_desc(1))');
fclose(anmVfile);


anmVAfile = fopen(sprintf('ANMmodeshapes_ALL_Cycle%d',cycle),'a');

fprintf(anmVAfile,'Cycle %d 1-30 ANM Slow Modes %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f %7.4f\n\n', cycle, w_snsh_a(resnum3-5-1:-1:resnum3-5-30,snsh_anm));
fprintf(anmVAfile,'\nCycle %d 1-30 ANM Slow Mode Vector x component Vx\n', cycle);
fprintf(anmVAfile,[repmat('%7.4f\t', 1, size(Vx(:,1:30), 2)) '\n'],Vx(:,1:30)');
fprintf(anmVAfile,'\nCycle %d 1-30 ANM Slow Mode Vector y component Vy\n', cycle);
fprintf(anmVAfile,[repmat('%7.4f\t', 1, size(Vy(:,1:30), 2)) '\n'],Vy(:,1:30)');
fprintf(anmVAfile,'\nCycle %d 1-30 ANM Slow Mode Vector z component Vz\n', cycle);
fprintf(anmVAfile,[repmat('%7.4f\t', 1, size(Vz(:,1:30), 2)) '\n'],Vz(:,1:30)');
fprintf(anmVAfile,'\nCycle %d 1-30 ANM Slow Mode Shapes\n',cycle);
fprintf(anmVAfile,[repmat('%7.4f\t', 1, size(slow_modes_anm(:,1:30), 2)) '\n'],slow_modes_anm(:,1:30)');
fclose(anmVAfile);

for mode=[index_overlap_desc(1),index_overlap_desc(2),index_overlap_desc(3)]
    
    ov = ov + 1;
    
    
    modesign = sign(overlap_diff_mode_reshape(mode));
    
    disp(modesign)
    
    
    for t=1:size(PDBdata.atomNum,2);
        
        PDBdata_ab.X(t) = PDBdata.X(t) + Vx(PDBdata.resNum(t),mode) * rescale(mode) * modesign;
        PDBdata_ab.Y(t) = PDBdata.Y(t) + Vy(PDBdata.resNum(t),mode) * rescale(mode) * modesign;
        PDBdata_ab.Z(t) = PDBdata.Z(t) + Vz(PDBdata.resNum(t),mode) * rescale(mode) * modesign;
        
    end
    
    if modesign == 1
        modesign_ab='a';
    elseif modesign == -1
        modesign_ab='b';
    end
    
    if ov == 1
        modesign_ov1_ab = modesign_ab;
    end
    
    PDBdata_ab.outfile=sprintf('1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb',mode,modesign_ab,DF,ov,cycle);
    
    mat2pdb(PDBdata_ab);
    
    % to modify pdb, add 'TER' lines
    ter_command = sprintf('head -5048 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb > 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb.1; printf ''TER\\n'' >> 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb.1; head -10096 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb | tail -5048  >> 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb.1; printf ''TER\\n'' >> 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb.1; head -13917 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb | tail -3821  >> 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb.1; printf ''TER\\n'' >> 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb.1; head -17738 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb | tail -3821 >> 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb.1; printf ''TER\\nEND\\n'' >> 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb.1; mv 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb.1 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb;',...
        mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle,...
        mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle);
    disp(ter_command);
    status = unix(ter_command)
    
    
    fprintf(tfile,'x%d=loadpdb 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.pdb \n',ov,mode,modesign_ab,DF,ov,cycle);
    fprintf(tfile,'saveamberparm x%d 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.top 1L7V_m%d%c_DF%3.1f_ov%d_cycle%d.coord \n',ov,mode,modesign_ab,DF,ov,cycle,mode,modesign_ab,DF,ov,cycle);
    
    
    file1size(ov)=length(sprintf('1L7V_m%d%c_DF%3.1f_ov%d', mode,modesign_ab,DF,ov));
    
    file1(ov,1:file1size(ov)) = sprintf('1L7V_m%d%c_DF%3.1f_ov%d', mode,modesign_ab,DF,ov);
    
    
    file2size(ov)=length(sprintf('1l7v_imp_simtgt_f0_m%d%c_DF%3.1f_ov%d', mode,modesign_ab,DF,ov));
    file2(ov,1:file2size(ov)) = sprintf('1l7v_imp_simtgt_f0_m%d%c_DF%3.1f_ov%d', mode,modesign_ab,DF,ov);
    
    
end


fprintf(tfile,'quit \n');
fclose(tfile);



for kk=1:10
    for j=1:resnum
        for i=1:resnum
            invcont(i,j)=0;
            for k=1:resnum-1
                if (k == resnum-kk)
                    invcont(i,j)=invcont(i,j)+U(i,k)*V(j,k)/w(k);
                end
            end
        end
    end
    
    
end

for j=1:resnum
    for i=1:resnum
        invcont_av10(i,j)=0;
        for k=1:resnum-1
            if (k >= resnum-10) % slow10 modes
                invcont_av10(i,j)=invcont_av10(i,j)+U(i,k)*V(j,k)/w(k);
            end
        end
    end
end



for j=1:resnum3
    for i=1:resnum3
        invhess1(i,j)=0;
        invhess2(i,j)=0;
        invhess3(i,j)=0;
        
        for k=1:resnum3-6
            if (k == resnum3-5-index_overlap_desc(1))
                invhess1(i,j)=invhess1(i,j)+Ua(i,k)*Va(j,k)/wa(k);
            end
            
            % for second and third best overlaps
            if (k == resnum3-5-index_overlap_desc(2))
                invhess2(i,j)=invhess2(i,j)+Ua(i,k)*Va(j,k)/wa(k);
            end
            
            if (k == resnum3-5-index_overlap_desc(3))
                invhess3(i,j)=invhess3(i,j)+Ua(i,k)*Va(j,k)/wa(k);
            end
        end
    end
end

for i=1:resnum
    fluc_x2(i)=invhess1(3*i-2,3*i-2);
    fluc_y2(i)=invhess1(3*i-1,3*i-1);
    fluc_z2(i)=invhess1(3*i,3*i);
    
    % for second and third best overlaps
    fluc_x2_2(i)=invhess2(3*i-2,3*i-2);
    fluc_y2_2(i)=invhess2(3*i-1,3*i-1);
    fluc_z2_2(i)=invhess2(3*i,3*i);
    
    fluc_x2_3(i)=invhess3(3*i-2,3*i-2);
    fluc_y2_3(i)=invhess3(3*i-1,3*i-1);
    fluc_z2_3(i)=invhess3(3*i,3*i);
    
    msf_anm(i,snsh_anm)=fluc_x2(i)+fluc_y2(i)+fluc_z2(i);
    
    % for second and third best overlaps
    msf_anm_2(i,snsh_anm)=fluc_x2_2(i)+fluc_y2_2(i)+fluc_z2_2(i);
    msf_anm_3(i,snsh_anm)=fluc_x2_3(i)+fluc_y2_3(i)+fluc_z2_3(i);
end

sum1=sum(msf_anm);
sum2=0;

% for second and third best overlaps
sum1_2=sum(msf_anm_2);
sum2_2=0;

sum1_3=sum(msf_anm_3);
sum2_3=0;


for i=1:resnum
    sum2=sum2+(1/sum1)*msf_anm(i,snsh_anm)*log(1/sum1*msf_anm(i,snsh_anm));
    
    % for second and third best overlaps
    sum2_2=sum2_2+(1/sum1_2)*msf_anm_2(i,snsh_anm)*log(1/sum1_2*msf_anm_2(i,snsh_anm));
    sum2_3=sum2_3+(1/sum1_3)*msf_anm_3(i,snsh_anm)*log(1/sum1_3*msf_anm_3(i,snsh_anm));
end

% Collectivity
deg_col(1)=exp(-1*sum2)/resnum;
% for second and third best overlaps
deg_col(2)=exp(-1*sum2_2)/resnum;
deg_col(3)=exp(-1*sum2_3)/resnum;


m = [index_overlap_desc(1),index_overlap_desc(2),index_overlap_desc(3)];

o = [overlap_desc(1),overlap_desc(2),overlap_desc(3)];

file3 = fname3;

